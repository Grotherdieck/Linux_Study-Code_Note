#include <iostream>
using namespace std;

int main()
{
	cout << "Hello Router!" << endl;
	return 0;
}

